import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Meninas super poderosas
      </Text>
      <View style={styles.imageContainer}>
        <Image style={styles.logo} source={require('../assets/power.png')} />
        <Image style={styles.logo} source={require('../assets/power2.png')} />
      </View>
      <Button title="Em ação" onPress={() => alert('Parabéns você avançou para a próxima fase!')} color="red" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4B0082',
    padding: 24,
  },
  paragraph: {
    margin: 29,
    marginTop: 1,
    fontSize: 19,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
  imageContainer: {
    flexDirection: 'row', // Isso faz com que os elementos fiquem em linha
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    height: 130,
    width: 99,
    margin: 8, // Adicione um espaço entre as imagens
  },
});
